public enum ExecutionResult {

    CONNECTION_ERROR,
    MALFORMED_HTML,
    SUCCESS,
    NO_TEXT_FOUND
}
